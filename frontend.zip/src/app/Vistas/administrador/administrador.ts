import { Component } from '@angular/core';

@Component({
  selector: 'app-administrador',
  imports: [],
  templateUrl: './administrador.html',
  styleUrl: './administrador.css'
})
export class Administrador {

}
